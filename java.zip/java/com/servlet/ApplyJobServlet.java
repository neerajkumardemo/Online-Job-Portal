package com.servlet;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.annotation.MultipartConfig;
import com.util.EmailSender;

@WebServlet("/ApplyJobServlet")
@MultipartConfig
public class ApplyJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String jIdStr = request.getParameter("job_id");
        int job_id = 0;
        try {
            if (jIdStr != null && !jIdStr.isEmpty() && !jIdStr.equals("null")) {
                job_id = Integer.parseInt(jIdStr);
            }
        } catch (NumberFormatException e) { job_id = 0; }

        if (job_id <= 0) {
            request.setAttribute("errorMessage", "Invalid Job ID.");
            request.getRequestDispatcher("apply.jsp").forward(request, response);
            return;
        }

        // File upload process
        Part filePart = request.getPart("resume");
        String fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName();
        String uploadPath = getServletContext().getRealPath("") + File.separator + "resume";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();
        filePart.write(uploadPath + File.separator + fileName);

     // ... (baaki imports aur file upload logic same rahega)

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobportal", "root", "admin123@");

            // 1. Session se email nikalna (Kyuki user login hai)
            HttpSession session = request.getSession(false);
            String userEmail = (String) session.getAttribute("userEmail"); 

            // 2. SQL Insert
            String sql = "INSERT INTO applications(name,email,phone,qualification,experience,skills,linkedin,cover_letter,resume,job_id,apply_date) VALUES(?,?,?,?,?,?,?,?,?,?,curdate())";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, request.getParameter("name"));
            ps.setString(2, userEmail); // ✅ Form ki jagah Session wali email save karein
            ps.setString(3, request.getParameter("phone"));
            ps.setString(4, request.getParameter("qualification"));
            ps.setString(5, request.getParameter("experience"));
            ps.setString(6, request.getParameter("skills"));
            ps.setString(7, request.getParameter("linkedin"));
            ps.setString(8, request.getParameter("cover"));
            ps.setString(9, fileName);
            ps.setInt(10, job_id);
            
            ps.executeUpdate();
            
            // ... (Email sender aur success message logic same)
            
            // EMAIL SENDING (Safely handled)
            try {
                String htmlBody = "<h2>Application Received!</h2><p>Hello " + request.getParameter("name") + ", your application has been submitted.</p>";
                EmailSender.sendEmail(request.getParameter("email"), "Application Received", htmlBody);
            } catch (Exception e) {
                System.out.println("Email bhejne mein error aaya, lekin DB mein save ho gaya: " + e.getMessage());
            }

            request.setAttribute("successMessage", "Application Submitted Successfully!");
            request.getRequestDispatcher("apply.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
            request.getRequestDispatcher("apply.jsp").forward(request, response);
        }
    }
}