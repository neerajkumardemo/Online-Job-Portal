package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.db.DBConnection;
import com.util.OTPUtil;
import com.util.EmailSender;

@WebServlet("/CompanyForgotPasswordServlet")
public class CompanyForgotPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        System.out.println("Action received: " + action);
        
        try {
            if ("sendOTP".equals(action)) {
                sendOTP(request, response);
            } else if ("verifyOTP".equals(action)) {
                verifyOTP(request, response);
            } else if ("resetPassword".equals(action)) {
                resetPassword(request, response);
            } else {
                sendJsonResponse(response, false, "Invalid action");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "Error: " + e.getMessage());
        }
    }
    
    private void sendOTP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        System.out.println("Send OTP requested for company: " + email);
        
        if (email == null || email.trim().isEmpty()) {
            sendJsonResponse(response, false, "Email is required!");
            return;
        }
        
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM companies WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()) {
                sendJsonResponse(response, false, "No company found with this email!");
                return;
            }
            
            String companyName = rs.getString("name");
            String otp = OTPUtil.generateOTP();
            OTPUtil.storeOTP(email, otp);
            
            // Attractive Email HTML Template for Company
            String subject = "🏢 JobPortal - Company Password Reset OTP";
            String htmlContent = getCompanyOTPEmailTemplate(companyName, otp);
            
            EmailSender.sendEmail(email, subject, htmlContent);
            
            String jsonResponse = "{\"success\":true,\"message\":\"OTP sent to " + email + "\",\"companyName\":\"" + companyName + "\"}";
            response.getWriter().write(jsonResponse);
            System.out.println("OTP sent to company: " + email + " - OTP: " + otp);
            
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "Database error: " + e.getMessage());
        }
    }
    
    private void verifyOTP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String otp = request.getParameter("otp");
        
        System.out.println("Verifying OTP for company: " + email + " - OTP: " + otp);
        
        if (email == null || otp == null) {
            sendJsonResponse(response, false, "Email and OTP are required!");
            return;
        }
        
        if (OTPUtil.verifyOTP(email, otp)) {
            sendJsonResponse(response, true, "OTP verified successfully!");
        } else {
            sendJsonResponse(response, false, "Invalid or expired OTP!");
        }
    }
    
    private void resetPassword(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String newPassword = request.getParameter("password");
        
        System.out.println("Resetting password for company: " + email);
        
        if (email == null || newPassword == null) {
            sendJsonResponse(response, false, "Email and password are required!");
            return;
        }
        
        if (newPassword.length() < 6) {
            sendJsonResponse(response, false, "Password must be at least 6 characters!");
            return;
        }
        
        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE companies SET password = ? WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, newPassword);
            ps.setString(2, email);
            
            int updated = ps.executeUpdate();
            
            if (updated > 0) {
                sendJsonResponse(response, true, "Password reset successfully!");
            } else {
                sendJsonResponse(response, false, "Failed to reset password!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "Database error: " + e.getMessage());
        }
    }
    
    private void sendJsonResponse(HttpServletResponse response, boolean success, String message) throws IOException {
        String json = "{\"success\":" + success + ",\"message\":\"" + message + "\"}";
        response.getWriter().write(json);
    }
    
    // ========== ATTRACTIVE COMPANY OTP EMAIL TEMPLATE ==========
    private String getCompanyOTPEmailTemplate(String companyName, String otp) {
        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Company Password Reset OTP - JobPortal</title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                body {
                    font-family: 'Segoe UI', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
                    background: linear-gradient(135deg, #1a2a3a 0%, #2c4a6e 100%);
                    padding: 40px 20px;
                }
                .email-container {
                    max-width: 580px;
                    margin: 0 auto;
                    background: #ffffff;
                    border-radius: 24px;
                    overflow: hidden;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
                    animation: fadeIn 0.5s ease;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .email-header {
                    background: linear-gradient(135deg, #1e3a5f 0%, #0f2b44 100%);
                    padding: 40px 30px;
                    text-align: center;
                }
                .logo {
                    font-size: 32px;
                    font-weight: 800;
                    color: white;
                    letter-spacing: -0.5px;
                }
                .logo span {
                    color: #ffc107;
                }
                .badge {
                    background: rgba(255,255,255,0.2);
                    display: inline-block;
                    padding: 6px 14px;
                    border-radius: 50px;
                    font-size: 12px;
                    color: white;
                    margin-top: 12px;
                }
                .email-content {
                    padding: 40px 35px;
                }
                .greeting {
                    font-size: 24px;
                    font-weight: 700;
                    color: #1a2a3a;
                    margin-bottom: 12px;
                }
                .greeting span {
                    color: #1e5a8a;
                }
                .message {
                    color: #4a5568;
                    line-height: 1.6;
                    margin-bottom: 25px;
                    font-size: 16px;
                }
                .otp-box {
                    background: linear-gradient(135deg, #f0f4ff 0%, #e8edff 100%);
                    border-radius: 20px;
                    padding: 30px;
                    text-align: center;
                    margin: 30px 0;
                    border: 1px solid rgba(30, 90, 138, 0.2);
                }
                .otp-label {
                    font-size: 14px;
                    text-transform: uppercase;
                    letter-spacing: 2px;
                    color: #1e5a8a;
                    font-weight: 600;
                    margin-bottom: 15px;
                }
                .otp-code {
                    font-size: 48px;
                    font-weight: 800;
                    letter-spacing: 8px;
                    color: #1e5a8a;
                    background: white;
                    display: inline-block;
                    padding: 15px 30px;
                    border-radius: 16px;
                    font-family: 'Courier New', monospace;
                    box-shadow: 0 5px 15px rgba(30, 90, 138, 0.2);
                }
                .expiry-info {
                    margin-top: 15px;
                    font-size: 13px;
                    color: #dc3545;
                    background: rgba(220, 53, 69, 0.1);
                    display: inline-block;
                    padding: 6px 14px;
                    border-radius: 30px;
                }
                .security-note {
                    background: #f0f2f5;
                    border-radius: 16px;
                    padding: 20px;
                    margin: 25px 0;
                    font-size: 13px;
                    color: #6c757d;
                    border-left: 4px solid #ffc107;
                }
                .button {
                    display: inline-block;
                    background: linear-gradient(135deg, #1e5a8a 0%, #0f3b5a 100%);
                    color: white;
                    padding: 14px 32px;
                    border-radius: 50px;
                    text-decoration: none;
                    font-weight: 600;
                    transition: transform 0.2s;
                }
                .button:hover {
                    transform: translateY(-2px);
                }
                .footer {
                    background: #f8f9fc;
                    padding: 25px 35px;
                    text-align: center;
                    border-top: 1px solid #e3e6f0;
                }
                .footer-links {
                    margin-bottom: 12px;
                }
                .footer-links a {
                    color: #1e5a8a;
                    text-decoration: none;
                    font-size: 13px;
                    margin: 0 10px;
                }
                .copyright {
                    font-size: 12px;
                    color: #9aa4b2;
                }
                @media (max-width: 600px) {
                    .email-container {
                        border-radius: 16px;
                    }
                    .email-content {
                        padding: 25px 20px;
                    }
                    .otp-code {
                        font-size: 32px;
                        letter-spacing: 5px;
                        padding: 12px 20px;
                    }
                }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="email-header">
                    <div class="logo">Job<span>Portal</span></div>
                    <div class="badge">🏢 Employer Account</div>
                </div>
                
                <div class="email-content">
                    <div class="greeting">
                        Hello <span>"" + companyName + ""</span>! 🏢
                    </div>
                    
                    <div class="message">
                        We received a request to reset your company account password for JobPortal. 
                        Use the secure OTP below to verify your identity and create a new password.
                    </div>
                    
                    <div class="otp-box">
                        <div class="otp-label">🔐 VERIFICATION CODE</div>
                        <div class="otp-code">"" + otp + ""</div>
                        <div class="expiry-info">
                            <i>⏰</i> This OTP expires in 5 minutes
                        </div>
                    </div>
                    
                    <div class="security-note">
                        <strong>🔒 Security Tips:</strong><br>
                        • Never share this OTP with anyone<br>
                        • JobPortal will never ask for your OTP over phone<br>
                        • If you didn't request this, please ignore this email
                    </div>
                    
                    <div style="text-align: center;">
                        <a href="#" class="button">Reset Company Password</a>
                    </div>
                </div>
                
                <div class="footer">
                    <div class="footer-links">
                        <a href="#">Employer Help</a> •
                        <a href="#">Privacy Policy</a> •
                        <a href="#">Contact Support</a>
                    </div>
                    <div class="copyright">
                        © 2026 JobPortal Inc. All rights reserved.<br>
                        Empowering businesses with top talent
                    </div>
                </div>
            </div>
        </body>
        </html>
        """;
    }
}