package com.servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/AdminDeleteCompanyServlet")
public class AdminDeleteCompanyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();
        
        if (idParam == null || idParam.isEmpty()) {
            session.setAttribute("errorMsg", "Invalid Company ID!");
            response.sendRedirect("admin_companies.jsp");
            return;
        }

        int companyId = Integer.parseInt(idParam);
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // Transaction start taaki sab kuch ek saath delete ho

            // 1. Delete all applications related to jobs of this company
            // Sub-query logic use kiya hai jo zyada fast hai loop se
            String deleteApps = "DELETE FROM applications WHERE job_id IN (SELECT id FROM jobs WHERE company_id = ?)";
            ps = con.prepareStatement(deleteApps);
            ps.setInt(1, companyId);
            ps.executeUpdate();
            ps.close();

            // 2. Delete all jobs of this company
            ps = con.prepareStatement("DELETE FROM jobs WHERE company_id = ?");
            ps.setInt(1, companyId);
            ps.executeUpdate();
            ps.close();
            
            // 3. Delete the company (Table name fixed: 'Companies')
            ps = con.prepareStatement("DELETE FROM Companies WHERE id = ?");
            ps.setInt(1, companyId);
            int result = ps.executeUpdate();
            
            if(result > 0) {
                con.commit(); // Sab delete hone ke baad commit karein
                session.setAttribute("succMsg", "Company and all associated data deleted successfully!");
            } else {
                con.rollback();
                session.setAttribute("errorMsg", "Company not found!");
            }
            
        } catch(Exception e) {
            try { if(con != null) con.rollback(); } catch(SQLException se) { se.printStackTrace(); }
            e.printStackTrace();
            session.setAttribute("errorMsg", "Error: " + e.getMessage());
        } finally {
            try { if(ps != null) ps.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
        
        response.sendRedirect("admin_companies.jsp");
    }
}