package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.db.DBConnection;
import com.util.OTPUtil;
import com.util.EmailSender;

@WebServlet("/CandidateForgotPasswordServlet")
public class CandidateForgotPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        System.out.println("========== FORGOT PASSWORD DEBUG ==========");
        System.out.println("Action received: " + action);
        
        try {
            if ("sendOTP".equals(action)) {
                sendOTP(request, response);
            } else if ("verifyOTP".equals(action)) {
                verifyOTP(request, response);
            } else if ("resetPassword".equals(action)) {
                resetPassword(request, response);
            } else {
                sendJsonResponse(response, false, "Invalid action");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "Error: " + e.getMessage());
        }
    }
    
    private void sendOTP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        System.out.println("Send OTP requested for: " + email);
        
        if (email == null || email.trim().isEmpty()) {
            sendJsonResponse(response, false, "Email is required!");
            return;
        }
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            // Get database connection
            con = DBConnection.getConnection();
            System.out.println("Database connection successful");
            
            // Check if email exists in users table
            String query = "SELECT * FROM users WHERE email = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, email);
            rs = ps.executeQuery();
            
            if (!rs.next()) {
                System.out.println("Email not found: " + email);
                sendJsonResponse(response, false, "No account found with this email!");
                return;
            }
            
            String userName = rs.getString("name");
            System.out.println("User found: " + userName);
            
            // Generate 6-digit numeric OTP (ONLY NUMBERS 0-9)
            String otp = generateNumericOTP();
            System.out.println("Generated OTP: " + otp);
            
            // Store OTP
            OTPUtil.storeOTP(email, otp);
            System.out.println("OTP stored successfully");
            
            // Attractive Email HTML Template
            String subject = "🔐 JobPortal - Password Reset OTP";
            String htmlContent = getAttractiveOTPEmailTemplate(userName, otp);
            
            // Send Email
            System.out.println("Sending email to: " + email);
            EmailSender.sendEmail(email, subject, htmlContent);
            System.out.println("Email sent successfully");
            
            // Send JSON response with userName
            String jsonResponse = "{\"success\":true,\"message\":\"OTP sent successfully\",\"userName\":\"" + userName + "\"}";
            response.getWriter().write(jsonResponse);
            
            System.out.println("=========================================");
            System.out.println("✅ OTP sent to: " + email);
            System.out.println("👤 User Name: " + userName);
            System.out.println("🔢 OTP: " + otp);
            System.out.println("=========================================");
            
        } catch (Exception e) {
            System.err.println("ERROR in sendOTP: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "Database error: " + e.getMessage());
        } finally {
            // Close resources
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
    
    // Generate 6-digit numeric OTP (ONLY NUMBERS 0-9)
    private String generateNumericOTP() {
        int otpNumber = (int)(Math.random() * 900000) + 100000;
        return String.valueOf(otpNumber);
    }
    
    private void verifyOTP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String otp = request.getParameter("otp");
        
        System.out.println("Verifying OTP for: " + email + " - OTP: " + otp);
        
        if (email == null || otp == null) {
            sendJsonResponse(response, false, "Email and OTP are required!");
            return;
        }
        
        if (OTPUtil.verifyOTP(email, otp)) {
            sendJsonResponse(response, true, "OTP verified successfully!");
        } else {
            sendJsonResponse(response, false, "Invalid or expired OTP! Please request a new one.");
        }
    }
    
    private void resetPassword(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String newPassword = request.getParameter("password");
        
        System.out.println("Resetting password for: " + email);
        
        if (email == null || newPassword == null) {
            sendJsonResponse(response, false, "Email and password are required!");
            return;
        }
        
        if (newPassword.length() < 6) {
            sendJsonResponse(response, false, "Password must be at least 6 characters!");
            return;
        }
        
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = DBConnection.getConnection();
            String query = "UPDATE users SET password = ? WHERE email = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, newPassword);
            ps.setString(2, email);
            
            int updated = ps.executeUpdate();
            
            if (updated > 0) {
                sendJsonResponse(response, true, "Password reset successfully!");
            } else {
                sendJsonResponse(response, false, "Failed to reset password!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "Database error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
    
    private void sendJsonResponse(HttpServletResponse response, boolean success, String message) throws IOException {
        String json = "{\"success\":" + success + ",\"message\":\"" + message + "\"}";
        response.getWriter().write(json);
        System.out.println("Response sent: " + json);
    }
    
 // ========== ATTRACTIVE OTP EMAIL TEMPLATE FIXED ==========
    private String getAttractiveOTPEmailTemplate(String userName, String otp) {
        // String.format ka use karein taaki variables sahi se replace hon
        return String.format("""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: 'Segoe UI', sans-serif; background: #f4f7f6; padding: 20px; }
                .email-container { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
                .email-header { background: #701524; padding: 30px; text-align: center; color: white; }
                .email-content { padding: 40px; text-align: center; }
                .greeting { font-size: 22px; font-weight: 700; color: #333; margin-bottom: 10px; }
                .otp-code { font-size: 45px; font-weight: 800; letter-spacing: 8px; color: #701524; background: #fff5f6; padding: 15px 30px; border-radius: 12px; display: inline-block; margin: 20px 0; border: 2px dashed #701524; }
                .footer { background: #f8f9fc; padding: 20px; text-align: center; font-size: 12px; color: #999; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="email-header">
                    <h2 style="margin:0;">Job<span style="color:#ffc107;">Portal</span></h2>
                </div>
                <div class="email-content">
                    <div class="greeting">Hello, %s!</div>
                    <p style="color:#666;">We received a request to reset your password. Use the code below to verify:</p>
                    <div class="otp-code">%s</div>
                    <p style="color:#dc3545; font-size:13px;">⏰ Valid for 5 minutes only.</p>
                </div>
                <div class="footer">
                    © 2026 JobPortal Inc. All rights reserved.
                </div>
            </div>
        </body>
        </html>
        """, userName, otp); // Yahan %s ki jagah variables automatically fit ho jayenge
    }
}