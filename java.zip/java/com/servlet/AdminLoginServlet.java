package com.servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            con = DBConnection.getConnection();
            
            if(con == null) {
                response.sendRedirect("admin_login.jsp?error=db");
                return;
            }
            
            String query = "SELECT id, username, full_name FROM admin WHERE username = ? AND password = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            
            rs = ps.executeQuery();
            
            if(rs.next()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("admin_id", rs.getInt("id"));
                session.setAttribute("admin_name", rs.getString("full_name"));
                session.setAttribute("admin_username", rs.getString("username"));
                session.setMaxInactiveInterval(1800);
                
                response.sendRedirect("admin_dashboard.jsp");
            } else {
                response.sendRedirect("admin_login.jsp?error=invalid");
            }
            
        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin_login.jsp?error=system");
        } finally {
            try { if(rs != null) rs.close(); } catch(Exception e) {}
            try { if(ps != null) ps.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
    }
}