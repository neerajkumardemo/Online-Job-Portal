package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.db.DBConnection;

@WebServlet("/DeleteJobServlet")
public class DeleteJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Dashboard se aane wali Job ID ko fetch karna
        int jobId = Integer.parseInt(request.getParameter("id"));
        HttpSession session = request.getSession();

        try {
            Connection con = DBConnection.getConnection();
            
            // Query to delete job
            String query = "DELETE FROM jobs WHERE id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, jobId);
            
            int i = ps.executeUpdate();
            
            if (i == 1) {
                session.setAttribute("succMsg", "Job Deleted Successfully!");
            } else {
                session.setAttribute("errorMsg", "Something went wrong on server.");
            }
            
            // Wapas Dashboard par redirect karna
            response.sendRedirect("admin_dashboard.jsp");
            
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMsg", "Error: " + e.getMessage());
            response.sendRedirect("admin_dashboard.jsp");
        }
    }
}