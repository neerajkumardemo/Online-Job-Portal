package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.db.DBConnection;

@WebServlet("/CompanyRegisterServlet")
public class CompanyRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String website = request.getParameter("website");
        String location = request.getParameter("location");
        String description = request.getParameter("description");
        
        // ========== VALIDATION ==========
        
        // Check required fields
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.trim().isEmpty() ||
            website == null || website.trim().isEmpty() ||
            location == null || location.trim().isEmpty() ||
            description == null || description.trim().isEmpty()) {
            
            showAlert(response, "error", "Validation Error", "All fields are required!", "company_register.jsp");
            return;
        }
        
        // Password length validation
        if (password.length() < 6) {
            showAlert(response, "error", "Password Too Short", 
                     "Password must be at least 6 characters long!", 
                     "company_register.jsp");
            return;
        }
        
        // Email validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            showAlert(response, "error", "Invalid Email", 
                     "Please enter a valid email address!", 
                     "company_register.jsp");
            return;
        }
        
        // Website URL validation
        if (!website.matches("^(https?://)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([/\\w \\.-]*)*/?$")) {
            showAlert(response, "error", "Invalid Website URL", 
                     "Please enter a valid website URL!", 
                     "company_register.jsp");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            
            // Check if company already exists with same email
            String checkQuery = "SELECT * FROM companies WHERE email = ?";
            PreparedStatement checkPs = con.prepareStatement(checkQuery);
            checkPs.setString(1, email);
            ResultSet rs = checkPs.executeQuery();
            
            if (rs.next()) {
                showAlert(response, "error", "Email Already Exists", 
                         "A company is already registered with this email!", 
                         "company_register.jsp");
                return;
            }
            
            // Check if company name already exists
            String checkNameQuery = "SELECT * FROM companies WHERE name = ?";
            PreparedStatement checkNamePs = con.prepareStatement(checkNameQuery);
            checkNamePs.setString(1, name);
            ResultSet rsName = checkNamePs.executeQuery();
            
            if (rsName.next()) {
                showAlert(response, "error", "Company Name Already Exists", 
                         "A company with name '" + name + "' is already registered!", 
                         "company_register.jsp");
                return;
            }
            
            // Insert new company
            String query = "INSERT INTO companies(name, email, password, website, location, description) VALUES(?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, website);
            ps.setString(5, location);
            ps.setString(6, description);

            int result = ps.executeUpdate();

            if (result > 0) {
                // Success - Show beautiful success message
                showSuccessAlert(response, name, email);
            } else {
                showAlert(response, "error", "Registration Failed", 
                         "Something went wrong. Please try again!", 
                         "company_register.jsp");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(response, "error", "Database Error", 
                     "Error: " + e.getMessage(), 
                     "company_register.jsp");
        }
    }
    
    // Helper method to show SweetAlert and redirect
    private void showAlert(HttpServletResponse response, String icon, String title, String message, String redirectUrl) 
            throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<script>");
        out.println("Swal.fire({");
        out.println("  icon: '" + icon + "',");
        out.println("  title: '" + title + "',");
        out.println("  text: '" + message.replace("'", "\\'") + "',");
        out.println("  confirmButtonColor: '#4e73df'");
        out.println("}).then(function() {");
        out.println("  window.location.href = '" + redirectUrl + "';");
        out.println("});");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
    }
    
    // Helper method to show success alert with options
    private void showSuccessAlert(HttpServletResponse response, String companyName, String email) 
            throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<script>");
        out.println("Swal.fire({");
        out.println("  icon: 'success',");
        out.println("  title: 'Company Registration Successful! 🎉',");
        out.println("  html: '<div style=\"text-align: left;\">' +");
        out.println("        '<p><strong>" + companyName + "</strong> has been successfully registered!</p>' +");
        out.println("        '<hr>' +");
        out.println("        '<p><i class=\"fa-solid fa-envelope\" style=\"color:#4e73df;\"></i> <strong>Email:</strong> " + email + "</p>' +");
        out.println("        '<p><i class=\"fa-solid fa-building\" style=\"color:#4e73df;\"></i> <strong>Company:</strong> " + companyName + "</p>' +");
        out.println("        '<hr>' +");
        out.println("        '<p class=\"text-success\">✓ Account created successfully!</p>' +");
        out.println("        '<p>Now you can post jobs and find the best talent for your organization.</p>' +");
        out.println("        '</div>',");
        out.println("  confirmButtonText: 'Login to Dashboard',");
        out.println("  confirmButtonColor: '#4e73df',");
        out.println("  showCancelButton: true,");
        out.println("  cancelButtonText: 'Go to Home',");
        out.println("  cancelButtonColor: '#6c757d'");
        out.println("}).then(function(result) {");
        out.println("  if (result.isConfirmed) {");
        out.println("    window.location.href = 'company_login.jsp';");
        out.println("  } else {");
        out.println("    window.location.href = 'index.jsp';");
        out.println("  }");
        out.println("});");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
    }
}