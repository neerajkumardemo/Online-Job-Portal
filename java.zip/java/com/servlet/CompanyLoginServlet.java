package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.db.DBConnection;

@WebServlet("/CompanyLoginServlet")
public class CompanyLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validation
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("loginError", "Email and Password are required!");
            request.getRequestDispatcher("company_login.jsp").forward(request, response);
            return;
        }
        
        // Email format validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            request.setAttribute("loginError", "Please enter a valid email address!");
            request.getRequestDispatcher("company_login.jsp").forward(request, response);
            return;
        }
        
        // Password length validation
        if (password.length() < 6) {
            request.setAttribute("loginError", "Password must be at least 6 characters long!");
            request.getRequestDispatcher("company_login.jsp").forward(request, response);
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM companies WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                String dbPassword = rs.getString("password");
                String companyName = rs.getString("name");
                int companyId = rs.getInt("id");
                
                if (dbPassword.equals(password)) {
                    // Login successful - Create session
                    HttpSession session = request.getSession();
                    session.setAttribute("companyId", companyId);
                    session.setAttribute("companyName", companyName);
                    session.setAttribute("companyEmail", email);
                    session.setAttribute("isCompanyLoggedIn", true);
                    
                    // Redirect to company dashboard
                    response.sendRedirect("company_dashboard.jsp");
                    
                } else {
                    request.setAttribute("loginError", "Invalid password! Please try again.");
                    request.getRequestDispatcher("company_login.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("loginError", "No company found with this email! Please register first.");
                request.getRequestDispatcher("company_login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("loginError", "Database error occurred. Please try again.");
            request.getRequestDispatcher("company_login.jsp").forward(request, response);
        }
    }
}