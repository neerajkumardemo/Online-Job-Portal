package com.servlet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/AddJobServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 1, // 1MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 15)   // 15MB
public class AddJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Character Encoding set karein (Important for Salary Symbols)
        request.setCharacterEncoding("UTF-8");
        
        // 2. Form se parameters get karein
        String title = request.getParameter("title");
        String company = request.getParameter("company");
        String location = request.getParameter("location"); // New Location Field
        String salary = request.getParameter("salary");
        String description = request.getParameter("description");
        String experience = request.getParameter("experience"); 
        String jobType = request.getParameter("job_type");     
        
        // 3. Logo Upload handling
        Part filePart = request.getPart("logo");
        String fileName = (filePart != null) ? filePart.getSubmittedFileName() : "";
        String logoPath = "uploads/default-logo.png"; // Default path agar logo na ho

        if (fileName != null && !fileName.isEmpty()) {
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            filePart.write(uploadPath + File.separator + fileName);
            logoPath = "uploads/" + fileName;
        }

        HttpSession session = request.getSession();
        Integer companyId = (Integer) session.getAttribute("companyId");

        // Check if company is logged in
        if (companyId == null) {
            response.sendRedirect("company_login.jsp");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            
            // Database Query (Ensure sequence matches your table columns)
            String sql = "INSERT INTO jobs(title, company, location, salary, description, company_id, experience, job_type, logo_url) VALUES(?,?,?,?,?,?,?,?,?)";
            
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, title);
                ps.setString(2, company);
                ps.setString(3, location);
                ps.setString(4, salary);
                ps.setString(5, description);
                ps.setInt(6, companyId);
                ps.setString(7, experience);
                ps.setString(8, jobType);
                ps.setString(9, logoPath);
                
                int i = ps.executeUpdate();
                if (i > 0) {
                    session.setAttribute("msg", "Job Posted Successfully!");
                    response.sendRedirect("viewjobs.jsp");
                } else {
                    session.setAttribute("errorMsg", "Something went wrong on server!");
                    response.sendRedirect("addjob.jsp");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMsg", "Database Error: " + e.getMessage());
            response.sendRedirect("addjob.jsp");
        }
    }
}