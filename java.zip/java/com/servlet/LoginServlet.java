package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // ========== VALIDATION ==========
        
        // Check if fields are empty
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("loginError", "Email and Password are required!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }
        
        // Email format validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            request.setAttribute("loginError", "Please enter a valid email address!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }
        
        // Password length validation
        if (password.length() < 6) {
            request.setAttribute("loginError", "Password must be at least 6 characters long!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            // Query to check user credentials
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email.trim());
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // User exists, check password
                    String dbPassword = rs.getString("password");
                    String userName = rs.getString("name");
                    int userId = rs.getInt("id");
                    
                    if (dbPassword.equals(password.trim())) {
                        // Login successful - Create session
                        HttpSession session = request.getSession();
                        session.setAttribute("userId", userId);
                        session.setAttribute("userName", userName);
                        session.setAttribute("userEmail", email.trim());
                        session.setAttribute("userRole", "Candidate");
                        session.setAttribute("isLoggedIn", true);
                        
                        // Redirect to dashboard
                        response.sendRedirect("dashboard.jsp");
                        
                    } else {
                        // Password incorrect
                        request.setAttribute("loginError", "Invalid password! Please try again.");
                        request.getRequestDispatcher("login.jsp").forward(request, response);
                    }
                } else {
                    // Email not found
                    request.setAttribute("loginError", "No account found with this email! Please register first.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("loginError", "Database error occurred. Please try again.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}