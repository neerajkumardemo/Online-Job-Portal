package com.servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/AdminDeleteJobServlet")
public class AdminDeleteJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();
        
        // Basic Validation
        if (idParam == null || idParam.isEmpty()) {
            session.setAttribute("errorMsg", "Invalid Job ID!");
            response.sendRedirect("admin_jobs.jsp");
            return;
        }

        int jobId = Integer.parseInt(idParam);
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // Transaction shuru karein

            // 1. Pehle is job se judi sari applications delete karein (Foreign Key Constraint handling)
            String deleteAppsQuery = "DELETE FROM applications WHERE job_id = ?";
            ps = con.prepareStatement(deleteAppsQuery);
            ps.setInt(1, jobId);
            ps.executeUpdate();
            ps.close();
            
            // 2. Ab main Job ko delete karein
            String deleteJobQuery = "DELETE FROM jobs WHERE id = ?";
            ps = con.prepareStatement(deleteJobQuery);
            ps.setInt(1, jobId);
            int result = ps.executeUpdate();
            
            if(result > 0) {
                con.commit(); // Dono operations successful hone par hi save karein
                session.setAttribute("succMsg", "Job deleted successfully!");
            } else {
                con.rollback(); // Agar job nahi mili toh rollback
                session.setAttribute("errorMsg", "Job not found!");
            }
            
        } catch(Exception e) {
            try { 
                if(con != null) con.rollback(); 
            } catch(SQLException se) { 
                se.printStackTrace(); 
            }
            e.printStackTrace();
            session.setAttribute("errorMsg", "Error deleting job: " + e.getMessage());
        } finally {
            try { if(ps != null) ps.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
        
        response.sendRedirect("admin_jobs.jsp");
    }
}