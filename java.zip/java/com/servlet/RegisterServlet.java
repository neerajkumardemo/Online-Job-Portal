package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.db.DBConnection;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String skills = request.getParameter("skills");
        
        // Validation: Check if any field is empty (except skills)
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.trim().isEmpty() ||
            phone == null || phone.trim().isEmpty()) {
            
            showAlert(response, "error", "Validation Error", "All fields are required!", "register.jsp");
            return;
        }
        
        // ========== PASSWORD LENGTH VALIDATION - MINIMUM 8 CHARACTERS ==========
        if (password.length() < 8) {
            showAlert(response, "error", "Password Too Short", 
                     "Password must be at least 8 characters long! Your password has " + password.length() + " characters.", 
                     "register.jsp");
            return;
        }
        
        // Optional: Password maximum length check (50 characters)
        if (password.length() > 50) {
            showAlert(response, "error", "Password Too Long", 
                     "Password cannot exceed 50 characters!", 
                     "register.jsp");
            return;
        }
        
        // Phone validation - exactly 10 digits
        if (!phone.matches("[0-9]{10}")) {
            showAlert(response, "error", "Invalid Phone Number", 
                     "Please enter a valid 10-digit phone number!", 
                     "register.jsp");
            return;
        }
        
        // Email validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            showAlert(response, "error", "Invalid Email", 
                     "Please enter a valid email address!", 
                     "register.jsp");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            
            // Check if email already exists
            String checkQuery = "SELECT * FROM users WHERE email = ?";
            PreparedStatement checkPs = con.prepareStatement(checkQuery);
            checkPs.setString(1, email);
            ResultSet rs = checkPs.executeQuery();
            
            if (rs.next()) {
                showAlert(response, "error", "Email Already Exists", 
                         "This email is already registered. Please login or use another email!", 
                         "register.jsp");
                return;
            }
            
            // Check if phone already exists
            String checkPhoneQuery = "SELECT * FROM users WHERE phone = ?";
            PreparedStatement checkPhonePs = con.prepareStatement(checkPhoneQuery);
            checkPhonePs.setString(1, phone);
            ResultSet rsPhone = checkPhonePs.executeQuery();
            
            if (rsPhone.next()) {
                showAlert(response, "error", "Phone Number Already Exists", 
                         "This phone number is already registered. Please use another number!", 
                         "register.jsp");
                return;
            }
            
            // Insert new user
            String query = "INSERT INTO users(name, email, password, phone, skills) VALUES(?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, phone);
            ps.setString(5, skills != null ? skills : "");

            int i = ps.executeUpdate();

            if (i > 0) {
                // Success - Show success message with options
                showSuccessAlert(response, name);
            } else {
                showAlert(response, "error", "Registration Failed", 
                         "Something went wrong. Please try again!", 
                         "register.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(response, "error", "Database Error", 
                     e.getMessage().replace("'", "\\'"), 
                     "register.jsp");
        }
    }
    
    // Helper method to show SweetAlert and redirect
    private void showAlert(HttpServletResponse response, String icon, String title, String message, String redirectUrl) 
            throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<script>");
        out.println("Swal.fire({");
        out.println("  icon: '" + icon + "',");
        out.println("  title: '" + title + "',");
        out.println("  text: '" + message + "',");
        out.println("  confirmButtonColor: '#4e73df'");
        out.println("}).then(function() {");
        out.println("  window.location.href = '" + redirectUrl + "';");
        out.println("});");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
    }
    
    // Helper method to show success alert with options
    private void showSuccessAlert(HttpServletResponse response, String name) 
            throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<script>");
        out.println("Swal.fire({");
        out.println("  icon: 'success',");
        out.println("  title: 'Registration Successful! 🎉',");
        out.println("  html: '<strong>" + name + "</strong>, your account has been created successfully!<br><br>✓ Password: 8+ characters<br>✓ Email verified<br>✓ Phone verified<br><br>Welcome to JobPortal!',");
        out.println("  confirmButtonText: 'Login Now',");
        out.println("  confirmButtonColor: '#4e73df',");
        out.println("  showCancelButton: true,");
        out.println("  cancelButtonText: 'Go to Home',");
        out.println("  cancelButtonColor: '#6c757d'");
        out.println("}).then(function(result) {");
        out.println("  if (result.isConfirmed) {");
        out.println("    window.location.href = 'login.jsp';");
        out.println("  } else {");
        out.println("    window.location.href = 'index.jsp';");
        out.println("  }");
        out.println("});");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
    }
}