package com.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/ViewApplications") 
public class ViewApplicationsServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        
        // Validation check: Company login hai ya nahi
        if (session == null || session.getAttribute("companyId") == null) {
            response.sendRedirect("company_login.jsp");
            return;
        }

        int companyId = (int) session.getAttribute("companyId");
        List<Map<String, String>> applicationsList = new ArrayList<>();

        try (Connection con = DBConnection.getConnection()) {
            
            // Query jo jobs aur applications ko join karegi
            String sql = "SELECT a.id, a.name, a.email, a.status, a.resume, j.title as job_title " +
                         "FROM applications a " + 
                         "JOIN jobs j ON a.job_id = j.id " +
                         "WHERE j.company_id = ? ORDER BY a.id DESC";
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, companyId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> app = new HashMap<>();
                app.put("id", String.valueOf(rs.getInt("id")));
                app.put("name", rs.getString("name"));
                app.put("email", rs.getString("email"));
                app.put("job_title", rs.getString("job_title"));
                
                String status = rs.getString("status");
                app.put("status", (status == null || status.isEmpty()) ? "Pending" : status);
                
                app.put("resume", rs.getString("resume"));
                applicationsList.add(app);
            }
            
            // Debugging ke liye (Eclipse console check karein)
            System.out.println("Company ID " + companyId + " ke liye " + applicationsList.size() + " applicants mile.");
            
            request.setAttribute("applicationsList", applicationsList);
            request.getRequestDispatcher("view_application.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}