package com.servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

@WebServlet("/AdminDeleteUserServlet")
public class AdminDeleteUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();
        
        if (idParam == null || idParam.isEmpty()) {
            session.setAttribute("errorMsg", "User ID missing!");
            response.sendRedirect("admin_users.jsp");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            int userId = Integer.parseInt(idParam);
            con = DBConnection.getConnection();
            
            // Maine applications wala delete hata diya hai kyunki 
            // aapke DB mein 'user_id' column nahi mil raha hai.
            
            // Seedha user ko delete karein
            String deleteUser = "DELETE FROM users WHERE id = ?";
            ps = con.prepareStatement(deleteUser);
            ps.setInt(1, userId);
            
            int result = ps.executeUpdate();
            
            if(result > 0) {
                session.setAttribute("succMsg", "User deleted successfully!");
            } else {
                session.setAttribute("errorMsg", "User not found in database!");
            }
            
        } catch(Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMsg", "Database Error: " + e.getMessage());
        } finally {
            try { if(ps != null) ps.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
        
        response.sendRedirect("admin_users.jsp");
    }
}