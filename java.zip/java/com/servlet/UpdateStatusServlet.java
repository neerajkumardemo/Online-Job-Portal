package com.servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection; // Aapka common DB connection
import com.util.EmailSender;

@WebServlet("/UpdateStatusServlet")
public class UpdateStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        String status = request.getParameter("status");

        if (idParam == null || status == null) {
            response.sendRedirect("ViewApplications");
            return;
        }

        int id = Integer.parseInt(idParam);

        try (Connection con = DBConnection.getConnection()) {
            
            if ("Delete".equals(status)) {
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM applications WHERE id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
            } else {
                // Update Database Status
                try (PreparedStatement ps = con.prepareStatement("UPDATE applications SET status=? WHERE id=?")) {
                    ps.setString(1, status);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                }

                // Fetch candidate details for email
                try (PreparedStatement psEmail = con.prepareStatement("SELECT name, email FROM applications WHERE id=?")) {
                    psEmail.setInt(1, id);
                    try (ResultSet rs = psEmail.executeQuery()) {
                        if (rs.next()) {
                            String name = rs.getString("name");
                            String email = rs.getString("email");
                            
                            String subject;
                            String htmlBody;

                            if ("Selected".equals(status) || "Shortlisted".equals(status)) {
                                subject = "🎉 Congratulations! You are Shortlisted";
                                htmlBody = "<div style='font-family:Arial; padding:20px; border:2px solid #28a745; border-radius:15px; max-width:600px;'>" +
                                           "<h2 style='color:#28a745;'>Interview Invitation!</h2>" +
                                           "<p>Dear <b>" + name + "</b>,</p>" +
                                           "<p>We are excited to inform you that your profile has been <b>shortlisted</b> for the next round.</p>" +
                                           "<br><p>Best of luck!<br><b>Job Portal Team</b></p></div>";
                            } else {
                                subject = "Update regarding your Job Application";
                                htmlBody = "<div style='font-family:Arial; padding:20px; border:2px solid #6c757d; border-radius:15px; max-width:600px;'>" +
                                           "<h2 style='color:#6c757d;'>Application Update</h2>" +
                                           "<p>Dear <b>" + name + "</b>,</p>" +
                                           "<p>After reviewing your profile, we are unable to move forward at this time.</p>" +
                                           "<br><p>Keep growing!<br><b>Job Portal Team</b></p></div>";
                            }
                            
                            // Email send karne ki koshish (Agar EmailSender ready hai)
                            try {
                                EmailSender.sendEmail(email, subject, htmlBody);
                            } catch (Exception ex) {
                                System.out.println("Email send nahi ho paya: " + ex.getMessage());
                            }
                        }
                    }
                }
            }
            // Fix: Redirect to Servlet instead of missing JSP
            response.sendRedirect("ViewApplications"); 

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error: " + e.getMessage());
        }
    }
}