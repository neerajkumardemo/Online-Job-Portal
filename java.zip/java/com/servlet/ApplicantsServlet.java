package com.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.db.DBConnection;

// ✅ Annotation must match the URL you call from the dashboard
@WebServlet("/ApplicantsServlet") 
public class ApplicantsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        
        // 1. Session check: Agar login nahi hai toh redirect
        if (session == null || session.getAttribute("companyId") == null) {
            response.sendRedirect("company_login.jsp?error=Please Login First");
            return;
        }

        // 2. Company ID ko safely nikalna
        int companyId = Integer.parseInt(session.getAttribute("companyId").toString());
        List<Map<String, String>> appsList = new ArrayList<>();

        try (Connection con = DBConnection.getConnection()) {
            
            // 3. SQL Join: Sirf is company ki jobs ke applicants uthao
            String sql = "SELECT a.id, a.name, a.email, a.resume, a.status, j.title as job_title " +
                         "FROM applications a " +
                         "INNER JOIN jobs j ON a.job_id = j.id " +
                         "WHERE j.company_id = ? " +
                         "ORDER BY a.id DESC";
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, companyId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> app = new HashMap<>();
                app.put("id", String.valueOf(rs.getInt("id")));
                app.put("name", rs.getString("name"));
                app.put("email", rs.getString("email"));
                app.put("job_title", rs.getString("job_title"));
                app.put("resume", rs.getString("resume"));
                
                // Status check: Agar null ho toh 'Pending' dikhaye
                String status = rs.getString("status");
                app.put("status", (status == null || status.isEmpty()) ? "Pending" : status);
                
                appsList.add(app);
            }

            // 4. Data ko JSP pe bhejna
            request.setAttribute("applicationsList", appsList);
            RequestDispatcher rd = request.getRequestDispatcher("applicants.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            // Console mein error check karne ke liye
            System.out.println("Error in ApplicantsServlet: " + e.getMessage());
            response.sendRedirect("company_dashboard.jsp?error=Database Error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}