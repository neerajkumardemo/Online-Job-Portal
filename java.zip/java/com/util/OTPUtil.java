package com.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class OTPUtil {
    
    private static Map<String, OTPData> otpStore = new HashMap<>();
    
    static class OTPData {
        String otp;
        long expiryTime;
        
        OTPData(String otp) {
            this.otp = otp;
            this.expiryTime = System.currentTimeMillis() + (5 * 60 * 1000); // 5 minutes
        }
        
        boolean isExpired() {
            return System.currentTimeMillis() > expiryTime;
        }
    }
    
    // Generate 6-digit numeric OTP (ONLY NUMBERS 0-9)
    public static String generateOTP() {
        Random random = new Random();
        // Generate number between 100000 and 999999 (6 digits)
        int otpNumber = 100000 + random.nextInt(900000);
        return String.valueOf(otpNumber);
    }
    
    // Store OTP
    public static void storeOTP(String email, String otp) {
        otpStore.put(email, new OTPData(otp));
        System.out.println("✅ OTP Stored for " + email + ": " + otp);
    }
    
    // Verify OTP
    public static boolean verifyOTP(String email, String otp) {
        OTPData data = otpStore.get(email);
        
        if (data == null) {
            System.out.println("❌ OTP not found for: " + email);
            return false;
        }
        
        if (data.isExpired()) {
            otpStore.remove(email);
            System.out.println("⏰ OTP expired for: " + email);
            return false;
        }
        
        if (data.otp.equals(otp)) {
            otpStore.remove(email);
            System.out.println("✅ OTP verified for: " + email);
            return true;
        }
        
        System.out.println("❌ Invalid OTP for: " + email + " - Expected: " + data.otp + " Got: " + otp);
        return false;
    }
    
    // Remove OTP
    public static void removeOTP(String email) {
        otpStore.remove(email);
        System.out.println("🗑️ OTP removed for: " + email);
    }
}