-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: jobportal
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `experience` varchar(50) DEFAULT NULL,
  `skills` varchar(200) DEFAULT NULL,
  `linkedin` varchar(200) DEFAULT NULL,
  `cover_letter` text,
  `resume` varchar(200) DEFAULT NULL,
  `apply_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (16,9,'Neeraj Kumar','Neeraj720000@gmail.com','8847399071','MSc IT','3+ Years','python','https://www.linkedin.com/login','aSZVgh','1774544247515_Resume.pdf','2026-03-26','Shortlisted'),(17,9,'Neeraj Kumar','demokumar118@gmail.com','8847399071','MSc IT','Fresher','java','https://www.linkedin.com/login','cscsdbfnm','1774629305915_Resume.pdf','2026-03-27','Rejected'),(18,10,'Neeraj Kumar','demokumar118@gmail.com','8847399071','MSc IT','Fresher','java','https://www.linkedin.com','sacdvfg','1774629588776_Resume.pdf','2026-03-27','Shortlisted'),(19,10,'Manisha Kumari','manisha123@gmail.com','9888931683','B tech','1 Year','HTML, CSS, and JavaScript','https://www.linkedin.com/login','iheogslfc','1775392790921_Resume.pdf','2026-04-05','Pending'),(20,11,'Sanya Bansal ','sanyabansal2112003@gmail.com','7973873062','Bca','Fresher','Python ','https://www.linkedin.com/in/sanya-bansal-378ab43b0?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app','Hdns sbs','1775448992429_Chapter 5 VR,AR and MR.pptx','2026-04-06','Pending'),(21,11,'Sanya Bansal ','sanyabansal2112003@gmail.com','7973873062','Bca','Fresher','Python ','https://www.linkedin.com/in/sanya-bansal-378ab43b0?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app','Hdns sbs','1775448999229_Chapter 5 VR,AR and MR.pptx','2026-04-06','Pending'),(22,11,'Sanya Bansal ','sanyabansal2112003@gmail.com','7973873062','Bca','Fresher','Python ','https://www.linkedin.com/in/sanya-bansal-378ab43b0?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app','Hdns sbs','1775449003403_Chapter 5 VR,AR and MR.pptx','2026-04-06','Selected'),(23,11,'Neeraj Kumar','tcs123@gmail.com','8847399071','BCA','2 Years','sales Executive','https://www.linkedin.com','sdzxhcjc','1775489827393_Resume.pdf','2026-04-06','Pending'),(24,10,'diwanshu Kumar','kumarsuchit1614@gmail.com','8847399077','MSc IT','Fresher','HTML, CSS, and JavaScript','https://www.linkedin.com','zxc','1775489917588_Resume.pdf','2026-04-06','Selected'),(25,10,'diwanshu Kumar','tcs123@gmail.com','0884739907','MSc IT','Fresher','c#','https://www.linkedin.com','gthnjm','1775491454298_Resume.pdf','2026-04-06','Pending'),(26,9,'diwanshu Kumar','admin@gmail.com','8847399071','BCA','Fresher','java','https://www.linkedin.com/login','dsff','1775491844327_Resume.pdf','2026-04-06','Pending'),(27,11,'diwanshu Kumar','admin@gmail.com','0884739071','BCA','Fresher','c#','https://www.linkedin.com','rstdyfugihojp','1775491905880_Resume.pdf','2026-04-06','Pending'),(28,11,'Neeraj Kumar','admin@gmail.com','0884739658','BA','1 Year','sales Executive','https://www.linkedin.com','neeraj','1775495713470_Resume.pdf','2026-04-06','Pending'),(29,9,'demo','admin@gmail.com','8847399072','MSc IT','1 Year','sales Executive','https://www.linkedin.com/login','esdf','1775530466504_Resume.pdf','2026-04-07','Selected'),(30,17,'Neeraj Kumar','Neeraj720000@gmail.com','8847399071','MSc IT','1 Year','machine learning','https://www.linkedin.com','fdgjkl;\'','1775553057619_Resume.pdf','2026-04-07','Pending'),(31,13,'Harikesh Kumar','shrikeshkumar123@gmail.com','9878277213','B tech','1 Year','machine learning','https://www.linkedin.com/login','i have a good knowledge about this','1775566224211_Resume.pdf','2026-04-07','Pending'),(32,19,'Harikesh Kumar','shrikeshkumar123@gmail.com','7747399071','B tech','Fresher','machine learning','https://www.linkedin.com','I have good knowledge about this job','1775566343796_Resume.pdf','2026-04-07','Rejected'),(33,19,'daman','damansharma4545@gmail.com','9687951487','B tech','3+ Years','python','https://www.linkedin.com/login','i am hard worker','1776237668940_Resume.pdf','2026-04-15','Selected'),(34,31,'Manisha kumari','Neeraj123@gmail.com','8847399045','Bca','0-1 Year','Python','https://www.ibm.com/in-en/careers/search','ag','1776997998389_Resume.pdf','2026-04-24','Pending'),(35,30,'Manisha kumari','Neeraj123@gmail.com','8847399045','B tech','0-1 Year','Python','https://www.ibm.com/in-en/careers/search','dfhkcu','1776998146195_Resume.pdf','2026-04-24','Pending');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-24 10:53:41
