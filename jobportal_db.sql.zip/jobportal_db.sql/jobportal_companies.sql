-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: jobportal
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (11,'TCS','tcs123@gmail.com','123456','https://www.tcs.com/','Ludhiana','I got talented employee'),(14,'wipro','wiprosuppor12@gmail.com','wipro123','https://www.wipro.com/','Banglore','Wipro Limited is a leading Indian multinational company that provides IT (Information Technology), consulting, and business process services. It is one of the top IT companies in India.\r\n\r\nFounded: 1945\r\nFounder: M. H. Hasham Premji\r\nHeadquarters: Bengaluru, India\r\nCEO: Srini Pallia\r\nEmployees: 2.4+ lakh worldwide'),(15,'Google','googlesuppor12@gmail.com','google123','https://www.google.com/','USA','Google mainly works in the IT and internet services field.\r\nð It provides products and services used worldwide.\r\n\r\nð Popular Google Products:\r\nGoogle Search (search engine)\r\nYouTube (video platform)\r\nGmail (email service)\r\nGoogle Maps (navigation)\r\nAndroid (mobile operating system)\r\nGoogle Chrome (web browser)'),(16,'MicroSoft','microsoftsupport12@gmail.com','Microsoft123','https://www.microsoft.com/en-in','USA','icrosoft Corporation ek global technology company hai jo software, hardware, cloud computing aur artificial intelligence (AI) ke field me kaam karti hai. Iski shuruaat 1975 me Bill Gates aur Paul Allen ne ki thi, aur iska headquarters Redmond, Washington (USA) me hai.\r\n\r\nMicrosoft ka main aim hai:\r\nð âEmpower every person and every organization on the planet to achieve more.â'),(17,'Amazon','amazonupport12@gmail.com','amazon123','https://www.amazon.jobs/en/','Mumbai','About the Role\r\n\r\nAmazon is looking for a highly analytical and detail-oriented Business Analyst (BTAO) to support data-driven decision-making across operations, product, and business teams. The ideal candidate will work closely with cross-functional stakeholders to generate insights, improve processes, and drive business growth.\r\n\r\nKey Responsibilities\r\nAnalyze large datasets to identify trends, patterns, and business opportunities\r\nDevelop dashboards and reports using tools like SQL, Excel, and Tableau/Power BI\r\nWork with stakeholders to define business metrics and KPIs\r\nAutomate reporting processes to improve efficiency\r\nProvide actionable insights to improve customer experience and operational performance\r\nSupport business teams in strategic planning and forecasting\r\nPerform root cause analysis for operational issues\r\nBasic Qualifications\r\nBachelorâs degree in Engineering, Business, Statistics, or related field\r\nStrong knowledge of SQL and Excel\r\nAnalytical thinking and problem-solving skills\r\nGood communication and stakeholder management skills\r\nPreferred Qualifications\r\nExperience with Python/R for data analysis\r\nKnowledge of data visualization tools (Tableau, Power BI)\r\nExperience in e-commerce, operations, or supply chain\r\nFamiliarity with Amazon Leadership Principles\r\nKey Skills\r\nData Analysis\r\nSQL\r\nExcel (Advanced)\r\nDashboarding\r\nBusiness Insights\r\nProblem Solving\r\nCommunication'),(18,'IBM','ibmsupport12@gmail.com','ibm123','https://www.ibm.com/in-en/careers/search','Hyderabad','like an IBMer.\r\nFrom leading the way in groundbreaking technologies to making a difference in local communities, bring your skills to transform the way the world works.\r\n\r\n');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-24 10:53:42
